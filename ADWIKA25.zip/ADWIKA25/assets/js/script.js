const registerButton = document.getElementById('register-button')

registerButton.addEventListener('mouseenter', function(){
    registerButton.style.transform = 'rotate(0deg)'
    registerButton.style.boxShadow = '0 10px 10px rgba(251, 111, 72, 0.797)'
})
registerButton.addEventListener('mouseleave', function(){
    registerButton.style.transform = 'rotate(-10deg)'
    registerButton.style.boxShadow = '0 4px 6px rgba(251, 111, 72, 0.1)'
})

function getRandomInt() {
    return Math.floor(Math.random() * 6);
}

const prankMessages = [
    'Click Me',
    'Try again',
    'Better luck next time',
    'Come meet me in hackathon!',
    'There is no place like 127.0.0.1',
    'Do you know, Afreedi has some special things for you'
]
const movingImage = document.getElementById('moving_image')
const prankMessageBox = document.getElementById('moving_image_content')

movingImage.addEventListener('mouseenter', () => {
    const maxX = window.innerWidth - movingImage.clientWidth;
    const maxY = window.innerHeight - movingImage.clientHeight;

    const randomX = Math.random() * maxX;
    const randomY = Math.random() * maxY;

    movingImage.style.transform = `translate(${randomX}px, ${randomY}px)`;
    prankMessageBox.textContent = prankMessages[getRandomInt()]
});